function addTokens(input, tokens){
    if (typeof input !== 'string')
        throw new Error('Invalid input');

    if (input.length < 6)
        throw new Error('Input should have at least 6 characters');

    for (var index in tokens) {
        if (!('tokenName' in tokens[index]) || (typeof tokens[index].tokenName !== 'string') || (Object.keys(tokens[index]).length) > 1) 
            throw new Error('Invalid array format')
    }

    var words = input.split('...');

    if (words.length < 2)
        return input
    
    output = '';
    words_index = 0;
    for (let tokens_index = 0; words_index < tokens.length; words_index++) {
        output += words[words_index++] + "${" + tokens[tokens_index].tokenName + "}";
    }

    if (words_index < words.length)
        output += words[words_index];

    return output
}

const app = {
    addTokens: addTokens
}

module.exports = app;